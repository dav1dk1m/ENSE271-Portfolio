## ENSE271 LAB 2: Asset Inventories and Site-Maps

For my lab2 assignment, I used Gong cha website ([Gong Cha](https://gong-cha.ca/)) to do Asset Inventories and Site-Map.

I actually did find some functions or erros that needs to update in the website and by doing this will improve the design, UX/UI and functionality.

***
### Files:

* [Site-Map](https://github.com/dav1dk1m/ENSE271-Portfolio/blob/main/LAB/lab2/sitemap_DongYun%20Kim.png)

* [Asset Inventories](https://github.com/dav1dk1m/ENSE271-Portfolio/blob/main/LAB/lab2/asset-inventory_Gong%20Cha.xlsx)
