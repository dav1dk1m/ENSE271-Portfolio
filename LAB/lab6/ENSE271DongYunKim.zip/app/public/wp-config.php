<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'ugiRC2q/mX079h0uUYbPuRKqJdOxTXHuz/2C/SfYAsiYn/2aW7NSyvlK6dEqJoj8sYwwGVuNr03edBxizgF+eQ==');
define('SECURE_AUTH_KEY',  'qkrhdZ1Yd61w3H05kiWGQ4l0tTyyHjtPhWQWUu9F6UGZUIgIJf30qydzmtsGXMdzjzhH48CNk+V668gok9aYDw==');
define('LOGGED_IN_KEY',    'lFnnUjEHlegSf8mEZ4feP8Ei0fOUYE5XQtqJAJ5aHGYGX9FJHa2gB2efRTGtKNU5St0ARQvrtXQ4TyN+qZlCMg==');
define('NONCE_KEY',        'W8eZn2SSWkmYniwllG35nAyqFcmuhqT+oyzolHoZJFjUeXrmx/Iw9I/JbZzyMzNn5KHUxCD/kL2tu5PMmRH1FQ==');
define('AUTH_SALT',        'XQwmxzCwSfeOX+vI/ZxF9zuWSnv86h5OutwPFnfAHhATf/lTRMFHkBcPRMyn5Oy1wsJfe3eFZuXa6BJGjoP0Lw==');
define('SECURE_AUTH_SALT', 'ToIeaq5hAfMq2KLMOFJMPpjJCl08KUog9qBBmzqqOdn+Z/h1YamrsgkrnC/CuWMhXEIqRLbp7LXBwAChormc8A==');
define('LOGGED_IN_SALT',   '0pJnN53ZA65Z10UAvo1o9xopNw5lKvaTrvl9PBAqlDWCCjxrDYkS3zoPiIjZurV5OA9P7dBriyrfIf1Uo4vOxQ==');
define('NONCE_SALT',       'KNo/hfnz6SBG5ep/Zdrd84uXEsQTSb3cg0Us3Ofd83Nn9O7mZgP+B94fqxxmMtAoTZIFQvz+8AWVYZdaSz/1Kg==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
